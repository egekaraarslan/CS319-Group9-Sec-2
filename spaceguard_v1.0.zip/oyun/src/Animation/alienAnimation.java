package Animation;

import javax.swing.ImageIcon;

public class alienAnimation extends Animation{
	
	public alienAnimation()
	{
		addFrame(new ImageIcon("img/heliboy.png").getImage(),  100);
		addFrame(new ImageIcon("img/heliboy3.png").getImage(), 100);
		addFrame(new ImageIcon("img/heliboy4.png").getImage(), 100);
		addFrame(new ImageIcon("img/heliboy5.png").getImage(), 100);
		addFrame(new ImageIcon("img/heliboy4.png").getImage(), 100);
		addFrame(new ImageIcon("img/heliboy3.png").getImage(), 100);
	}

}
