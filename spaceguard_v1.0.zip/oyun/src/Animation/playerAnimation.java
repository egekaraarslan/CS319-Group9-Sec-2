package Animation;

import javax.swing.ImageIcon;

public class playerAnimation extends Animation {

	public playerAnimation()
	{
		addFrame(new ImageIcon("alienAnim/anim0.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim1.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim2.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim3.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim4.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim5.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim6.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim7.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim8.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim9.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim10.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim11.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim12.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim13.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim14.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim15.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim16.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim17.png").getImage(),  100);
		addFrame(new ImageIcon("alienAnim/anim18.png").getImage(),  100);

	}
}
