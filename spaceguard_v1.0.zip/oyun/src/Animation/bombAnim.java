package Animation;


import javax.swing.ImageIcon;



public class bombAnim extends Animation{
	
	public bombAnim()
	{
		super();
		addFrame(new ImageIcon("bombAnim/1.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/2.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/3.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/4.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/5.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/6.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/7.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/6.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/5.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/4.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/3.png").getImage(),  100);
		addFrame(new ImageIcon("bombAnim/2.png").getImage(),  100);

	}

}
