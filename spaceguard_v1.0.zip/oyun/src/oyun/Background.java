package oyun;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Background {
	
	private Image bg,bg1;
	private int backSpeed=1;
	private int bgY,bg1Y;

	public Background()
	{
		bg=new ImageIcon("img/bg1.jpg").getImage();
		bg1=new ImageIcon("img/bg1.jpg").getImage();
		bgY=0;
		bg1Y=-600;
	}
	
	public void setBg(Image im)
	{
		bg=im;
		bg1=im;	}
	 public Image getBg() {
		return bg;
	}

	public Image getBg1() {
		return bg1;
	}

	public int getBgY() {
		return bgY;
	}

	public int getBg1Y() {
		return bg1Y;
	}


	
	
	public void update()
	{
		bg1Y+=backSpeed;
		bgY+=backSpeed;
		if(bgY>=600)
		{
			bgY=-600;
		}
		if(bg1Y>=600)
		{
			bg1Y=-600;
		}
	}

}
