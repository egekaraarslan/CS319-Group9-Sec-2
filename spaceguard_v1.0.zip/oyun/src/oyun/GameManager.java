package oyun;

import java.net.URL;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.Timer;

import screens.GamePanel;
import screens.PausePanel;
import screens.statusPanel;
import Animation.Animation.*;
import Animation.alienAnimation;
import Animation.bombAnim;
import Animation.playerAnimation;
import Objects.Bomb;
import Objects.spaceship;
import Objects.PowerUp;
import Objects.alien;

public class GameManager  implements Runnable{
	
	Random random=new Random();
	URL backUrl;
	URL fireUrl;
	boolean timeIncrease=false;
	
	GamePanel gamePanel;
	GameMapManager mapManager;
	statusPanel status;
	Thread gameThread;


	TimeManager time;
	
	boolean projectileEnable=true,isOver=false;

	int projectTime=0;
	boolean paused=false;
	
	GameMap map;
	
	SettingInfo info;
	public GameManager(statusPanel pan,GamePanel gamePanel,SettingInfo info)
	{
		this.gamePanel=gamePanel;
		this.info=info;
		this.status=pan;
		map=new GameMap();
		time=new TimeManager(this);
		mapManager=new GameMapManager(this);


		gameThread=new Thread(this);

		
		map.getBg().setBg(info.getBg());
		gameThread.start();
		
	}
	

	public void setTimeInc(boolean f)
	{
		this.timeIncrease=f;
	}
	public boolean getTimeInc()
	{
		return timeIncrease;
	}
	
	public GamePanel getGamePanel()
	{
		return gamePanel;
	}

	public void run() {
		// TODO Auto-generated method stub
		while(isOver==false&&paused==false)
		{
			
		time.update(timeIncrease);
		map.update(this);
		mapManager.update();
		status.repaint();
		

		
		if(projectileEnable==false)
		{
			projectTime+=1;
		}
		if(projectTime==30)
		{
			projectileEnable=true;
			projectTime=0;
		}
		
		

		
		if(isGameOver()){
			
			isOver=true;
			endGame();
		}
		try {
			gameThread.sleep(17);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}
	public boolean isProjectileEnable() {
		return projectileEnable;
	}
	public SettingInfo getInfo()
	{
		return info;
	}



	public void setProjectileEnable(boolean projectileEnable) {
		this.projectileEnable = projectileEnable;
	}

	public void continueGame()
	{
		gamePanel.setVisible(true);
		status.setVisible(true);
		gamePanel.setFocusable(true);
		gamePanel.requestFocusInWindow();
	}

	public void pauseGame() 
	{

		gamePanel.getFrame().getContentPane().add(new PausePanel(this));
		
		gamePanel.setVisible(false);
		status.setVisible(false);

	}
	public void endGame()
	{
		
		isOver=true;
		if(map.getPlayer().getHealth()<=0)
		{

			gamePanel.getFrame().showEndGame(map.getPlayer().getScore());
			gamePanel.setVisible(false);
			status.setVisible(false);

		}
		else
		{
		
			gamePanel.getFrame().showGameFinished(map.getPlayer().getScore());
			gamePanel.setVisible(false);
			status.setVisible(false);
		}
		
	}
	public boolean isGameOver()
	{
		if(map.getPlayer().getHealth()<=0||(info.getDifficulty()!="easy"&&status.getTime()<=0))
		{
			return true;
		}
		else
			return false;
	}
	public statusPanel getStatusPanel()
	{
		return status;
	}
	

	
	
	public void updateScore(int max,int increase,boolean chanceDecrease)
	{
		status.update(max, increase, chanceDecrease);
		map.getPlayer().setScore(map.getPlayer().getScore()+increase);
	}


	public ArrayList<PowerUp> getPowers()
	{
		return map.getPowers();
	}
	public Thread getGameThread() {
		return gameThread;
	}

	public spaceship getPlayer() {
		return map.getPlayer();
	}

	public Background getBg() {
		return map.getBg();
	}

	public alienAnimation getHanim() {
		return map.getAlienAnim();
	}

	public playerAnimation getPlayerAnim() {
		return map.getPlayerAnim();
	}

	public bombAnim getBombaAnim() {
		return map.getBombaAnim();
	}

	public ArrayList<alien> getEnemies() {
		return map.getEnemies();
	}

	public ArrayList<Bomb> getBombs() {
		return map.getBombs();
	}


}
