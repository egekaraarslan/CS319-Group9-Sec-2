package oyun;

import java.util.ArrayList;
import java.util.Random;

import Animation.alienAnimation;
import Animation.bombAnim;
import Animation.playerAnimation;
import Objects.Bomb;
import Objects.spaceship;
import Objects.PowerUp;
import Objects.alien;

public class GameMap {
	
	boolean spawnEnemy=true;
	int spawnTimer=0;
	ArrayList<alien> aliens;
	ArrayList<Bomb>  bombs;
	ArrayList<PowerUp> powers;
	spaceship spaceship;
	Background bg;
	alienAnimation alienAnim;
	playerAnimation playerAnim;
	bombAnim bombaAnim;
	
	Random random=new Random();
	public GameMap()
	{
		spaceship=new spaceship();
		bg=new Background();
		aliens=new ArrayList<alien>();
		bombs=new ArrayList<Bomb>();
		powers=new ArrayList<PowerUp>();
		bombaAnim=new bombAnim();
		playerAnim=new playerAnimation();
		
		alienAnim=new alienAnimation();
	}
	
	public void update(GameManager info)
	{
		spawnTimer+=1;
		if(spawnTimer==200)
		{
			spawnTimer=0;
			spawnEnemy=true;
		}
		if(spawnEnemy==true)
		{
			
			if(info.getInfo().getDifficulty().equals("easy"))
			{
				
				getEnemies().add(new alien(info,random.nextInt(800), 40,random.nextInt(3)+2));

			}
			else
			{
				getEnemies().add(new alien(info,random.nextInt(800), 40,random.nextInt(3)));

			}
			spawnEnemy=false;
		}
		
		
		getPlayer().update();
		getPlayer().updateProjectiles();
		getBg().update();
		getAlienAnim().update(50);
		getPlayerAnim().update(50);
		getBombaAnim().update(50);
		
		//UPDATE ENEM�ES
		for(int a=0;a<getEnemies().size();a++)
		{
			getEnemies().get(a).update();
		}
		
		//UPDATE BOMBS
		for(int a=0;a<getBombs().size();a++)
		{
			getBombs().get(a).update();
		}
		
		for(int a=0;a<getPowers().size();a++)
		{
			getPowers().get(a).update();
		}
	}
	
	public Background getBg()
	{
		return bg;
	}

	public ArrayList<alien> getEnemies() {
		return aliens;
	}

	public ArrayList<Bomb> getBombs() {
		return bombs;
	}

	public ArrayList<PowerUp> getPowers() {
		return powers;
	}

	public spaceship getPlayer() {
		return spaceship;
	}

	public alienAnimation getAlienAnim() {
		return alienAnim;
	}

	public playerAnimation getPlayerAnim() {
		return playerAnim;
	}

	public bombAnim getBombaAnim() {
		return bombaAnim;
	}

}
