package screens;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JButton;

import oyun.SettingInfo;
import oyun.mainFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import listeners.MenuActionListener;

public class MainMenu extends Menu{

	/**
	 * Create the panel.
	 */
	
	
	
	SettingInfo info;
	JButton btnNewGame,btnSettings,btnHelp,btnCredits,btnNewButton;
	Image img=new ImageIcon("img/menubg.jpg").getImage();
	
	
	public MainMenu(mainFrame f) {
		super(f);
		setSize(800,600);
		setLayout(null);
		this.info=new SettingInfo("easy", new ImageIcon("img/bg1.jpg").getImage());
		 btnNewGame = new JButton("NEW GAME!");
		btnNewGame.setBounds(165, 106, 159, 52);
		add(btnNewGame);
		
		 btnSettings = new JButton("SETTINGS");
		btnSettings.setBounds(165, 215, 159, 52);
		add(btnSettings);
		
		JButton btnHelp = new JButton("HELP");
		btnHelp.setBounds(165, 342, 159, 52);
		add(btnHelp);
		
		btnCredits = new JButton("CREDITS");
		btnCredits.setBounds(165, 447, 159, 52);
		add(btnCredits);
		
		JButton btnNewButton = new JButton("EXIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setBounds(165, 525, 159, 52);
		add(btnNewButton);
		
		MenuActionListener actionListener=new MenuActionListener(this,btnNewGame,btnSettings,btnHelp,btnCredits,btnNewButton);
		
		btnNewGame.addActionListener(actionListener);
		btnCredits.addActionListener(actionListener);
		btnHelp.addActionListener(actionListener);
		btnNewButton.addActionListener(actionListener);
		btnSettings.addActionListener(actionListener);


	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage(img, 0, 0, null);
	}

	public void startGame()
	{
		frame.getContentPane().add(new mainGamePanel(frame, info));
		setVisible(false);
	}
	public void displaySettings()
	{
		frame.getContentPane().add(new SettingsPanel(this));
		setVisible(false);
	}
	public void displayCredits()
	{
		frame.getContentPane().add(new CreditsPanel(frame));
		setVisible(false);
	}
	public void exitGame()
	{
		System.exit(0);
	}
	public void setInfo(SettingInfo info)
	{
		this.info=info;
	}
	public void applySettings(SettingInfo s)
	{
		setInfo(s);
	}
}
