package screens;

import javax.swing.JPanel;
import javax.swing.JLabel;

import oyun.SettingInfo;

import java.awt.Font;
import java.awt.Color;

public class statusPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	final JLabel target;
	final JLabel chance;
	final JLabel total;
	JLabel timer;

	int targetPoint;
	int totalChance;
	SettingInfo info;
	private int time;
	private float lastTime;
	public statusPanel(SettingInfo info) {
		setBackground(Color.PINK);
		setLayout(null);
		setSize(200,600);
		lastTime=System.currentTimeMillis();
		this.info=info;
		this.time=info.getTime();
		targetPoint=0;
		totalChance=3;
		JLabel lblTarget = new JLabel("TARGET");
		lblTarget.setForeground(Color.RED);
		lblTarget.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTarget.setBounds(49, 48, 74, 38);
		add(lblTarget);
		
		JLabel lblTotal = new JLabel("TOTAL");
		lblTotal.setForeground(Color.RED);
		lblTotal.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTotal.setBounds(49, 194, 74, 38);
		add(lblTotal);
		
		JLabel lblChance = new JLabel("CHANCE");
		lblChance.setForeground(Color.RED);
		lblChance.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblChance.setBounds(49, 336, 100, 38);
		add(lblChance);
		
		target = new JLabel("50");
		target.setForeground(Color.BLACK);
		target.setFont(new Font("Tahoma", Font.BOLD, 18));
		target.setBounds(75, 103, 74, 38);
		add(target);
		
		 total = new JLabel("0");
		total.setForeground(Color.BLACK);
		total.setFont(new Font("Tahoma", Font.BOLD, 18));
		total.setBounds(75, 248, 74, 38);
		add(total);
		
		 chance = new JLabel(""+totalChance);
		chance.setForeground(Color.BLACK);
		chance.setFont(new Font("Tahoma", Font.BOLD, 18));
		chance.setBounds(75, 407, 74, 38);
		add(chance);
	
		if(info.getDifficulty()!="easy")
		{
		
			JLabel label = new JLabel("Time Left");
			label.setBounds(103, 478, 74, 16);
			add(label);
			timer = new JLabel(""+time);
			timer.setBounds(113, 507, 40, 16);
			add(timer);
	
		}


	}
	
	public void update(int max,int increase,boolean chanceDecrease)
	{
		target.setText(""+max);
		targetPoint+=increase;
		total.setText(""+targetPoint);
		if(chanceDecrease==true)
		{
			totalChance--;
			chance.setText(""+totalChance);
		}
		
		repaint();
		
	}
	public int getTime()
	{
		return time;
	}
	
	public void updateTime(boolean increase)
	{
		if(increase)
		{
			time=time+5;
		}
		if(info.getDifficulty()!="easy")
		{
			time--;
			timer.setText(""+time);
			repaint();
		}
	
	}
	

	
}
