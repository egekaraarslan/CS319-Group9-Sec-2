package screens;

import javax.swing.JPanel;

import listeners.MenuActionListener;
import oyun.mainFrame;

public abstract class Menu extends JPanel {
	protected mainFrame frame;
	MenuActionListener actionListener;
	
	public Menu()
	{
		
	}
	public Menu(mainFrame f)
	{
		this.frame=f;
		actionListener=new MenuActionListener();
	}
	
}
