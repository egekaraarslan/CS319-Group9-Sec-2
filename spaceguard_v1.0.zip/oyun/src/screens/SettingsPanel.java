package screens;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JRadioButton;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JCheckBox;

import oyun.SettingInfo;

public class SettingsPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	JRadioButton rdbtnEasy;
	JRadioButton rdbtnMedium ;
	JRadioButton rdbtnHard;
	Image img=new ImageIcon("img/menubg.jpg").getImage();
	private JLabel label;
	ArrayList<Image> backgrounds=new ArrayList<Image>();
	int numberOfBackgrounds;
	int bgCounter;
	Image currentBg;
	String currentDif="easy";
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	
	MainMenu menu;
	


	public SettingsPanel(final MainMenu menu) {
		setSize(800,600);
		this.menu=menu;
		setLayout(null);
		numberOfBackgrounds=2;
		bgCounter=0;
		currentBg= new ImageIcon("img/bg0.jpg").getImage();
		JLabel lblDifficulty = new JLabel("DIFFICULTY");
		lblDifficulty.setForeground(Color.RED);
		lblDifficulty.setFont(new Font("Lucida Grande", Font.BOLD, 16));
		lblDifficulty.setBounds(25, 88, 148, 52);
		add(lblDifficulty);
		
		 rdbtnEasy = new JRadioButton("EASY");
		 rdbtnEasy.setFont(new Font("Lucida Grande", Font.BOLD, 15));
		 rdbtnEasy.setForeground(Color.WHITE);
		 rdbtnEasy.setSelected(true);
		rdbtnEasy.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				
				if(rdbtnEasy.isSelected()==true)
				{
					rdbtnHard.setSelected(false);
					rdbtnMedium.setSelected(false);
					currentDif="easy";
				}
			}
		});
		rdbtnMedium = new JRadioButton("MEDIUM");
		rdbtnMedium.setForeground(Color.WHITE);
		rdbtnMedium.setFont(new Font("Lucida Grande", Font.BOLD, 15));
		 rdbtnHard = new JRadioButton("HARD");
		 rdbtnHard.setFont(new Font("Lucida Grande", Font.BOLD, 15));
		 rdbtnHard.setForeground(Color.WHITE);

		rdbtnHard.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				
				if(rdbtnHard.isSelected()==true)
				{
					rdbtnEasy.setSelected(false);
					currentDif="hard";
					rdbtnMedium.setSelected(false);
				}
			}
		});	rdbtnMedium.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				
				if(rdbtnMedium.isSelected()==true)
				{
					currentDif="medium";
					rdbtnHard.setSelected(false);
					rdbtnEasy.setSelected(false);
				}
			}
		});
		rdbtnEasy.setBounds(241, 103, 141, 23);
		add(rdbtnEasy);
		
		rdbtnMedium.setBounds(411, 103, 141, 23);
		add(rdbtnMedium);
		
		rdbtnHard.setBounds(597, 103, 141, 23);
		add(rdbtnHard);
		
		label = new JLabel("BACKGROUND");
		label.setForeground(Color.RED);
		label.setFont(new Font("Lucida Grande", Font.BOLD, 16));
		label.setBounds(25, 227, 148, 52);
		add(label);
		
		ImageIcon left = new ImageIcon("img/left.png");

		btnNewButton = new JButton(left);
		
		btnNewButton.setBounds(272, 227, 88, 64);
		add(btnNewButton);
		
		ImageIcon right = new ImageIcon("img/right.png");
		btnNewButton_1 = new JButton(right);

		
		btnNewButton_1.setBounds(542, 227, 88, 64);
		add(btnNewButton_1);
		
		final JCheckBox chckbxUseDefault = new JCheckBox("USE DEFAULT");
		chckbxUseDefault.setForeground(Color.RED);
		chckbxUseDefault.setFont(new Font("Lucida Grande", Font.BOLD, 15));
		chckbxUseDefault.setBackground(Color.RED);
		chckbxUseDefault.setBounds(25, 381, 148, 23);
		add(chckbxUseDefault);
		
		JButton btnSave = new JButton("SAVE");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if(chckbxUseDefault.isSelected()==false)
				{
					menu.applySettings(new SettingInfo(currentDif, currentBg));

				}
				else
				{
					menu.setInfo(new SettingInfo("easy", new ImageIcon("img/bg1.jpg").getImage()));
				}
				menu.setVisible(true);
				setVisible(false);
				
			}
		});
		btnSave.setBounds(243, 508, 117, 29);
		add(btnSave);
		
		JButton btnCancel = new JButton("CANCEL");
		btnCancel.setBounds(468, 508, 117, 29);
		add(btnCancel);
		
		for(int a=0;a<numberOfBackgrounds;a++)
		{
			backgrounds.add(new ImageIcon("img/bg"+a+".jpg").getImage());
		}
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(bgCounter==0)
				{
					currentBg=backgrounds.get(numberOfBackgrounds-1);
					bgCounter=numberOfBackgrounds-1;
					repaint();
				}
				else
				currentBg=backgrounds.get(--bgCounter);
				repaint();
			}
		});
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(bgCounter==numberOfBackgrounds-1)
				{
					currentBg=backgrounds.get(0);
					bgCounter=0;
					repaint();
				}
				else
					currentBg=backgrounds.get(++bgCounter);
				repaint();
			}
			
		});

	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage(img, 0, 0, null);
		g.drawImage(currentBg,400,210,100,100,null);
		

	}
}
