package listeners;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import oyun.GameManager;

public class GameKeyListener  implements KeyListener{

	GameManager manager;
	public GameKeyListener(GameManager g)
	{
		this.manager=g;
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode()==e.VK_ESCAPE)
		{
			
				manager.pauseGame();
		
		}
		if(e.getKeyCode()==e.VK_SPACE&&manager.isProjectileEnable())
		{
			manager.getPlayer().shoot(manager.getPlayer().getX(),5);
			manager.setProjectileEnable(false);
		}
		if(e.getKeyCode()==e.VK_LEFT)
		{
			if(manager.getPlayer().getX()<0)
			{
				manager.getPlayer().setSpeedX(0);
			}
			else
			{
				manager.getPlayer().setSpeedX(-6);
				manager.getPlayer().setMovingLeft(true);

			}
		}
		else if(e.getKeyCode()==e.VK_RIGHT)
		{
			if(manager.getPlayer().getX()>750)
			{
				manager.getPlayer().setSpeedX(0);
			}
			else
			{
				manager.getPlayer().setSpeedX(6);
				manager.getPlayer().setMovingRight(true);
			}
			
		}
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode()==e.VK_LEFT)
		{
			manager.getPlayer().setSpeedX(0);
			manager.getPlayer().setMovingLeft(false);
		}
		else if(e.getKeyCode()==e.VK_RIGHT)
		{
			manager.getPlayer().setSpeedX(0);
			manager.getPlayer().setMovingRight(false);
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
