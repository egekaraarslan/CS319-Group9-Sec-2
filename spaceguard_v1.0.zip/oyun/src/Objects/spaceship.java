package Objects;

import java.awt.Image;
import java.util.ArrayList;

import javax.swing.ImageIcon;

public class spaceship extends GameObject {

	Image character;
	private int x;
	private int y;
	private int speedX;
	private boolean movingLeft=false;
	private boolean movingRight=false;
	ArrayList<laser> lasers;
	private int health;
	private int score;
	
	public spaceship()
	{
		score=0;
		this.id=1;
		this.health=3;
		lasers=new ArrayList<laser>();
		character=new ImageIcon("alienAnim/tmp-0.gif").getImage();
		setX(400);
		setY(400);
	}
	
	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public Image getImage()
	{
		return character;
	}
	public void update()
	{
		setX(getX() + getSpeedX());
		if(getSpeedX()>0)
		{
			setMovingRight(true);
		}
		if(getSpeedX()<0)
		{
			setMovingLeft(true);
		}
		if(getX()==-40)
		{
			setX(800);
		}
	}
	public ArrayList<laser> getProjectiles()
	{
		return lasers;
	}
	public void updateProjectiles()
	{
		for(int a=0;a<lasers.size();a++)
		{
			lasers.get(a).update();
		}
	}
	public void shoot(int x,int speed)
	{
		laser p=new laser(this);
		p.speed=speed;
		lasers.add(new laser(this));
	}

	@Override
	int getObjectId() {
		// TODO Auto-generated method stub
		return 1;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getSpeedX() {
		return speedX;
	}

	public void setSpeedX(int speedX) {
		this.speedX = speedX;
	}

	public boolean isMovingLeft() {
		return movingLeft;
	}

	public void setMovingLeft(boolean movingLeft) {
		this.movingLeft = movingLeft;
	}

	public boolean isMovingRight() {
		return movingRight;
	}

	public void setMovingRight(boolean movingRight) {
		this.movingRight = movingRight;
	}
}
