package Objects;

import java.awt.Image;

import javax.swing.ImageIcon;


public class PowerUp  extends GameObject{

	private int x;
	private int y;
	int speed=6;
	public boolean hit=false;
	private int type;
	public Image img;
	public PowerUp(int x,int y,int type)
	{
		this.id=2;
		this.x=x;
		this.y=y+30;
		this.setType(type);
		
		if(type==1)
		{
			img=new ImageIcon("img/healt.png").getImage();

		}
		else if(type==2)
		{
			img=new ImageIcon("img/slowdown.png").getImage();
		}
		else if(type==3)
		{
			img=new ImageIcon("img/bigbomb.png").getImage();

		}
		else if(type==4)
		{
			img=new ImageIcon("img/time.png").getImage();
		}

	}
	
	public Image getImage()
	{
		return img;
	}
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		y+=speed;

		
	}

	@Override
	public int getObjectId() {
		// TODO Auto-generated method stub
		return 2;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}
