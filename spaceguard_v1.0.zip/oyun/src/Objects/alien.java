package Objects;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;

import oyun.GameManager;

public class alien  extends GameObject{
	
	Random random=new Random();
	
	GameManager panel;
	public int x;
	public int y;
	public int speed=3;
	public int number;
	public boolean bombEnabled=true;
	public int bombTime;
	public int type=0;
	public long pastTime;
	public int life;
	
	public Image image;
	
	public alien(GameManager panel,int x,int y,int type)
	{
		this.id=0;
		this.panel=panel;
		this.x=x;
		number=random.nextInt(10);
		this.pastTime=System.currentTimeMillis();
		this.y=y;	
		this.type=type;
		if(type==1)
		{
			life=2;
			image=new ImageIcon("img/twohit.png").getImage();
		}
		else
		{
			life=1;

		}
	}
	
	public void  throwBomb()
	{
		if(bombEnabled==true)
		{

			if(this.type==1)
			{

				if(panel.getPlayer().isMovingLeft()==true&&panel.getPlayer().getX()-x>0)
				{
					int bombaYol=panel.getPlayer().getY()-y -35;
					int playerYol=panel.getPlayer().getX()-x;
					if(playerYol-bombaYol>50&&playerYol-bombaYol<100)
					{
						int type=random.nextInt(10);
						if(type==1||type==2||type==3)
						{
							panel.getPowers().add(new PowerUp(x, y, type));
							bombEnabled=false;
						}
						else
						{
						panel.getBombs().add(new Bomb(x,y,type));
						bombEnabled=false;
						}
					}							
				}
				else if(panel.getPlayer().isMovingRight()==true&&panel.getPlayer().getX()-x<0)
				{
					int bombaYol=panel.getPlayer().getY()-y -35;
					int playerYol=x-panel.getPlayer().getX();
					if(playerYol-bombaYol>50&&playerYol-bombaYol<100)
					{
						int type=random.nextInt(10);
						if(type==1||type==2||type==3)
						{
							panel.getPowers().add(new PowerUp(x, y, type));
							bombEnabled=false;
						}
						else
						{
						panel.getBombs().add(new Bomb(x,y,type));
						bombEnabled=false;
						}
					}	
				}
			}
			   else			
				{
					int type=random.nextInt(30);
					if(type==1||type==2||type==3)
					{
						panel.getPowers().add(new PowerUp(x, y, type));
						bombEnabled=false;
					}
					else
					{
						panel.getBombs().add(new Bomb(x,y,type));
						bombEnabled=false;
					}

				}
		}
		else
		{
			bombTime+=1;
			if(bombTime==200)
			{
				bombEnabled=true;
			}
		}
	}
	public void update()
	{
		throwBomb();
		long currentTime=System.currentTimeMillis();
		
		if(currentTime-pastTime>1000)
		{
			number++;
			if(number==10)
			{
				number=0;
			}
			pastTime=currentTime;
		}
		x+=speed;
		if(x>700)
		{
			speed=-speed;
		}
		if(x<0)
		{
			speed=-speed;
		}
		if(random.nextInt(100)==1)
		{
			speed=-speed;
		}
		
	}

	@Override
	int getObjectId() {
		// TODO Auto-generated method stub
		return id;
	}

}
