package Objects;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Bomb extends GameObject {

	private int x;
	public boolean hit;
	int speed=6;
	public Image bomb;

	private int y;
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int type;
	public Bomb(int x,int y,int type)
	{
		this.id=4;
		this.hit=false;
		this.x=x;
		this.y=y+30;
		this.type=type;
		

			bomb=new ImageIcon("img/bomb.png").getImage();

	}
	
	public void update()
	{
		y+=speed;
	}

	@Override
	int getObjectId() {
		// TODO Auto-generated method stub
		return id;
	}
}
