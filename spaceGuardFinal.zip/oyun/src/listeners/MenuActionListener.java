package listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import oyun.mainFrame;
import screens.MainMenu;
import screens.SettingsPanel;
import screens.mainGamePanel;

public class MenuActionListener implements ActionListener {

	JButton btnNewGame,btnSettings,btnHelp,btncredits,btnNewButton;
	JButton contin,back;
	MainMenu menu;
	

	public MenuActionListener(MainMenu m,JButton newg,JButton set,JButton help,JButton cred, JButton newbut)
	{
		this.menu=m;
		this.btnNewGame=newg;
		this.btnSettings=set;
		this.btnHelp=help;
		this.btnNewButton=newbut;
		this.btncredits=cred;

	}
	public MenuActionListener(MainMenu m,JButton c,JButton b)
	{
		this.menu=m;
		this.contin=c;
		this.back=b;
	}

	public MenuActionListener() {
		// TODO Auto-generated constructor stub
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==btnNewGame)
		{
			menu.startGame();
		}
		if(e.getSource()==btnSettings)
		{
			menu.displaySettings();
		}
		if(e.getSource()==btnNewButton)
		{
			menu.exitGame();
		}
		if(e.getSource()==btncredits)
		{
			System.out.println("cre");
			menu.displayCredits();
		}
		if(e.getSource()==btnHelp)
		{
			menu.displayHelp();
		}
		
	}

}
