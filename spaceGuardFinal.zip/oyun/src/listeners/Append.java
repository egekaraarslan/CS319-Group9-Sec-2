package listeners;




import java.io.File;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;

public class Append extends OutputStream
{
    // Dosya Erisimi Icin Gerekli Obje
    RandomAccessFile fd;

    // Constructor - Parametre Olarak, Yazilacak Dosyayi Aliyor
    public Append(String file)
    {
        try
        {
            // Dosyayi Ac
            File f = new File(file);
            // Eger Dosya Yoksa, Yarat
            if (!f.exists()) f.createNewFile();
            f = null;
            // RandomAccessFile objesini Dosyayi Kullanarak Ac
            // Acma Modu "rw"
            fd = new RandomAccessFile(file, "rw");
            // Dosyanın En Sonuna Git
            fd.seek(fd.length() - 1L);
        } catch (Exception ex) { }
  }

  public void close()
  { 
      try
      {
        fd.close();
      } catch (Exception ex) { }
  }

  public void write(byte[] b)
  {
      try
      {
        fd.write(b);
      } catch (Exception ex) { }
  }

  public void write(byte[] b, int off, int len)
  {
      try
      {
        fd.write(b, off, len);
      } catch (Exception ex) { }
  }

  public void write(int b)
  {
      try
      {
        fd.write(b);
      } catch (Exception ex) { }
  }
  
}