package Animation;

import java.awt.Image;

public class AnimationFrame {

	Image image;
	long endTime;
	   public AnimationFrame(Image image, long endTime) {
		      this.image = image;
		      this.endTime = endTime;
		   }
		}

