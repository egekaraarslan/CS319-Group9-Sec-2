package Objects;

public  abstract class GameObject {

	int id;
	abstract void update();
	abstract int getObjectId();
	
	
}
