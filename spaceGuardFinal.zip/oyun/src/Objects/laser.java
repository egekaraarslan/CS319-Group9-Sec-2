package Objects;


public class laser {
	
	private int x;
	private int y;
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	int speed=7;
	
	public laser(spaceship p)
	{
		this.x=p.getX()+5;
		this.y=p.getY()+5;
	}
	
	public void update()
	{
		y-=speed;
	}
	

}
