package oyun;

import java.awt.Image;

public class SettingInfo {
	
	private String difficulty;
	private Image bg;
	private int time;
	
	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public Image getBg() {
		return bg;
	}

	public void setBg(Image bg) {
		this.bg = bg;
	}
	public int getTime()
	{
		return time;
	}

	public SettingInfo(String dif,Image bg)
	{
		this.difficulty=dif;
		this.bg=bg;
		this.time=100;
	}

}
