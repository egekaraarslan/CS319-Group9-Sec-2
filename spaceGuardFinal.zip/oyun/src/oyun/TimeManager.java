package oyun;

public class TimeManager {

	float gameTime;
	long lastTime;
	GameManager manager;
	public TimeManager(GameManager manager)
	{
		lastTime=System.currentTimeMillis();
		this.manager=manager;
	}
	
	public void update(boolean timeIncrease)
	{

		if(System.currentTimeMillis()-lastTime>1000)
		{
			manager.getStatusPanel().updateTime(timeIncrease);
			manager.setTimeInc(false);
			lastTime=System.currentTimeMillis();
		}
	}
}
