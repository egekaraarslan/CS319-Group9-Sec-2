package oyun;

import java.awt.geom.Line2D;

import Objects.laser;
import Objects.alien;

public class GameMapManager {
GameManager manager;
	

public GameMapManager(GameManager manager)
{
	this.manager=manager;
}

public void update()
{
	manager.getGamePanel().repaint();
	isEnemyHit();
	critizePower();
	isPlayerHit();
}
public void isEnemyHit()
	{
		for(int enemy=0;enemy<manager.getEnemies().size();enemy++)
		{
			for(int bold=0;bold<manager.getPlayer().getProjectiles().size();bold++)
			{
				alien selectedEnemy=manager.getEnemies().get(enemy);
				laser selectedBold=manager.getPlayer().getProjectiles().get(bold);
				
				if(selectedBold.getX()>selectedEnemy.x+6 && selectedBold.getX()<selectedEnemy.x+70 && selectedBold.getY()<selectedEnemy.y+60)
				{
					manager.getEnemies().get(enemy).life--;
					
					if(manager.getEnemies().get(enemy).life==0)
					{
						if(manager.getEnemies().get(enemy).type==1)
						{
							manager.updateScore(100,15,false);

						}
						else if((manager.getEnemies().get(enemy).type==3))
								{
							manager.updateScore(100,30,false);

								}
						else{
							manager.updateScore(100,manager.getEnemies().get(enemy).number,false);

						}
						manager.getEnemies().remove(enemy);



					}
					manager.getPlayer().getProjectiles().remove(bold);
				}
			}
					
		}
	}
public void isPlayerHit()
{
	for(int a=0;a<manager.getBombs().size();a++)
	{
		int playerx1=manager.getPlayer().getX();
		int playerx2=playerx1+45;
		int playery=manager.getPlayer().getY()+80;
		int bombx1=manager.getBombs().get(a).getX();
		int bombx2=bombx1+30;
		int bomby=manager.getBombs().get(a).getY()+30;
				
		if(manager.getBombs().get(a).hit==false&&((playerx1<bombx1&&playerx2>bombx1)||(bombx2>playerx1&&bombx1<playerx1)||(bombx1>playerx1&&bombx2<playerx2))&&playery-bomby<10)
		{
			System.out.println("Player y = "+manager.getPlayer().getY()+" "+"bom y = "+manager.getBombs().get(a).getY());
			System.out.println("bom y = "+manager.getBombs().get(a).getY());
			manager.getPlayer().setHealth(manager.getPlayer().getHealth()-1);
			manager.getBombs().get(a).hit=true;
			manager.getBombs().remove(a);
			manager.updateScore(100, 0, true);
		}
	}
}

public void critizePower()
{
	for(int a=0;a<manager.getPowers().size();a++)
	{

		int playerx1=manager.getPlayer().getX();
		int playerx2=playerx1+45;
		int playery=manager.getPlayer().getY()+80;
		int bombx1=manager.getPowers().get(a).getX();
		int bombx2=bombx1+30;
		int bomby=manager.getPowers().get(a).getY()+30;
		if(manager.getPowers().get(a).hit==false&&(((playerx1<bombx1&&playerx2>bombx1)||(bombx2>playerx1&&bombx1<playerx1)||(bombx1>playerx1&&bombx2<playerx2))&&playery-bomby<10))
		{
			manager.getPowers().get(a).hit=true;
		
			
			if(manager.getPowers().get(a).getType()==1)
			{
				manager.getPlayer().setHealth(manager.getPlayer().getHealth()+1);
				manager.getStatusPanel().updateHealth(manager.getPlayer().getHealth());
				
			}
			else if(manager.getPowers().get(a).getType()==2)
			{
				for(int b=0;b<manager.getEnemies().size();b++)
				{
					manager.getEnemies().get(b).speed=1;
				}
				
			}
			else if(manager.getPowers().get(a).getType()==3)
			{
				for(int c=0;c<manager.getEnemies().size();c++)
				{
					manager.getEnemies().remove(c);
				}
			}		
			else if(manager.getPowers().get(a).getType()==4)
			{
				manager.setTimeInc(true);
			}
		}
		}
	}
}



