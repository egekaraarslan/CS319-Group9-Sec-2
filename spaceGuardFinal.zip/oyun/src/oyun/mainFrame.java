package oyun;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import screens.GameFinishedPanel;
import screens.GameOverPanel;
import screens.MainMenu;
import screens.mainGamePanel;

public class mainFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					mainFrame frame = new mainFrame();
					frame.setVisible(true);
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public mainFrame() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		contentPane.add(new MainMenu(this));
	}
	
	public void showGameFinished(int score)
	{
		contentPane.removeAll();
		contentPane.add(new GameFinishedPanel(this,score));
		contentPane.repaint();
	}
	public void showEndGame(int score)
	{
		contentPane.removeAll();

		contentPane.add(new GameOverPanel(this,score));
		contentPane.repaint();
	}
	public  void showMenu()
	{
		contentPane.removeAll();

		contentPane.add(new MainMenu(this));
		contentPane.repaint();
	}
	public void showGame()
	{

		mainGamePanel game=new mainGamePanel(this,new SettingInfo("easy", new ImageIcon("img/bg1.jpg").getImage()));
		contentPane.add(game);
		contentPane.repaint();
	}

}
