package screens;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import java.awt.Color;

import javax.swing.JLabel;

import oyun.mainFrame;

import java.awt.Font;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GameFinishedPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public GameFinishedPanel(final mainFrame f,final int score) {
		setBackground(Color.BLACK);

		setSize(800,600);
		setLayout(null);
		
		JLabel lblGameFinished = new JLabel("YOU WON!");
		lblGameFinished.setForeground(Color.WHITE);
		lblGameFinished.setFont(new Font("Lucida Grande", Font.BOLD, 44));
		lblGameFinished.setBounds(179, 46, 530, 119);
		add(lblGameFinished);
		
		JLabel lblYourScore = new JLabel("Your Score: ");
		lblYourScore.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblYourScore.setForeground(Color.GREEN);
		lblYourScore.setBounds(42, 230, 152, 62);
		add(lblYourScore);
		
		JLabel label = new JLabel(""+score);
		label.setForeground(Color.GREEN);
		label.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		label.setBounds(246, 230, 152, 62);
		add(label);
		
		ImageIcon back = new ImageIcon("img/left.png");

		JButton btnBack = new JButton(back);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				f.showMenu();
			}
		});
		btnBack.setBounds(42, 448, 74, 67);
		add(btnBack);
		
		ImageIcon repeat = new ImageIcon("img/replay.png");

		JButton btnNewButton = new JButton(repeat);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
				f.showGame();
			}
		});
		btnNewButton.setBounds(571, 456, 95, 74);
		add(btnNewButton);
	}

}
