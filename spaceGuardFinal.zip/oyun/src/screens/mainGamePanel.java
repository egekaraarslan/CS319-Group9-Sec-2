package screens;

import javax.swing.JPanel;

import oyun.SettingInfo;
import oyun.mainFrame;

public class mainGamePanel extends JPanel {

	/**
	 * Create the panel.
	 */
	GamePanel easyGamePanel_;
	statusPanel statusPanel_;
	public mainGamePanel(mainFrame f,SettingInfo info) {
		setLayout(null);
		
		statusPanel_ = new statusPanel(info);
		statusPanel_.setBounds(800, 0, 200, 600);
		add(statusPanel_);

		easyGamePanel_ = new GamePanel(statusPanel_,f,info);
		easyGamePanel_.requestFocusInWindow();
		easyGamePanel_.setBounds(0, 0, 800, 600);
		add(easyGamePanel_);

	}
}
