package screens;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;

import oyun.mainFrame;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreditsPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	mainFrame f;
	public CreditsPanel(final mainFrame f) {
		setBackground(Color.BLACK);
		
		this.f=f;
		setSize(800,600);
		setLayout(null);
		
		JLabel lblCredits = new JLabel("CREDITS");
		lblCredits.setBackground(Color.BLACK);
		lblCredits.setForeground(Color.RED);
		lblCredits.setFont(new Font("Lucida Grande", Font.BOLD, 36));
		lblCredits.setBounds(306, 46, 430, 84);
		add(lblCredits);
		
		JLabel lblFeritzcan = new JLabel("Ferit Özcan");
		lblFeritzcan.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblFeritzcan.setForeground(Color.WHITE);
		lblFeritzcan.setBounds(205, 135, 289, 77);
		add(lblFeritzcan);
		
		JLabel ege = new JLabel("Ege Karaarslan");
		ege.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		ege.setForeground(Color.WHITE);
		ege.setBounds(205, 185, 289, 77);
		add(ege);
		
		JLabel mehmet = new JLabel("Mehmet Ali Deligöz");
		mehmet.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		mehmet.setForeground(Color.WHITE);
		mehmet.setBounds(205, 235, 289, 77);
		add(mehmet);
		
		
		ImageIcon back = new ImageIcon("img/left.png");

		JButton btnBack = new JButton(back);
		btnBack.addActionListener(new ActionListener() {
			
		
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				f.showMenu();
			}
		});
		btnBack.setBounds(42, 448, 74, 67);
		add(btnBack);
		

	}
}
