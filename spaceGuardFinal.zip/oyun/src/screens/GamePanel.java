package screens;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Line2D;

import javax.swing.JPanel;

import listeners.GameKeyListener;
import oyun.Background;
import oyun.GameManager;
import oyun.SettingInfo;
import oyun.mainFrame;

public class GamePanel  extends JPanel {
	
	Background b;
	private static GameManager manager;
	statusPanel status;
	GameKeyListener keyListener;
	mainFrame f;
	MainMenu m;
	SettingInfo info;
	
	public GamePanel(statusPanel pan,mainFrame f,SettingInfo info)
	{
		this.f=f;
		this.m=m;
		this.info=info;
		status=pan;
		setFocusable(true);
		requestFocusInWindow(true);
		manager=createGameManager(pan);
		keyListener=new GameKeyListener(manager);
		addKeyListener(keyListener);
		setSize(800,600);
	}
	public GameManager createGameManager(statusPanel pna)
	{
		
			manager=new GameManager(status,this,info);
		
		return manager;
	}


	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage( manager.getBg().getBg(),0, manager.getBg().getBgY(), this);
		g.drawImage( manager.getBg().getBg1(),0, manager.getBg().getBg1Y(), this);
		
		g.setColor(Color.WHITE);
		
		
		g.drawImage(manager.getPlayerAnim().getImage(),manager.getPlayer().getX(), manager.getPlayer().getY()+80, this);

		
		//DRAW ENEM�ES
		for(int a=0;a<manager.getEnemies().size();a++)
		{
			if(manager.getEnemies().get(a).type==1||manager.getEnemies().get(a).type==3)
			{
				g.drawImage(manager.getEnemies().get(a).image, manager.getEnemies().get(a).x,manager.getEnemies().get(a).y, this);

			}
			else 
			{
				g.drawImage(manager.getHanim().getImage(), manager.getEnemies().get(a).x,manager.getEnemies().get(a).y, this);

			}

		}
		
		
		//DRAW NUMBERS
		for(int a=0;a<manager.getEnemies().size();a++)
		{
			if(manager.getEnemies().get(a).type==2)
			{

				g.setColor(Color.BLACK);

				g.setFont(new Font("Tahoma", Font.BOLD, 16));
				g.drawString(""+manager.getEnemies().get(a).number,manager.getEnemies().get(a).x+40,manager.getEnemies().get(a).y+120);
			}
		}
		
		//DRAW manager.getBombs()
		for(int a=0;a<manager.getBombs().size();a++)
		{

			if(manager.getBombs().get(a).type==1||manager.getBombs().get(a).type==2||manager.getBombs().get(a).type==3)
			{
				g.setColor(Color.WHITE);
				g.drawImage(manager.getBombs().get(a).bomb,manager.getBombs().get(a).getX(),manager.getBombs().get(a).getY(),this);

			}
			else
			{
				g.setColor(Color.WHITE);
				
				g.drawImage(manager.getBombaAnim().getImage(),manager.getBombs().get(a).getX(),manager.getBombs().get(a).getY(),this);

			}
			if(manager.getBombs().get(a).getY()>600)
			{
				manager.getBombs().remove(a);
			}
		}
		//draw powers
		for(int a=0;a<manager.getPowers().size();a++)
		{
			g.setColor(Color.WHITE);
			
			g.drawImage(manager.getPowers().get(a).getImage(), manager.getPowers().get(a).getX(), manager.getPowers().get(a).getY()	, this);

		}
		for(int a=0;a<manager.getPlayer().getProjectiles().size();a++)
		{
			if(manager.getPlayer().getProjectiles().get(a).getY()<0)
			{
				manager.getPlayer().getProjectiles().remove(a);
			}
			else
			{
				
				g.setColor(Color.RED);
				g.fillRect(manager.getPlayer().getProjectiles().get(a).getX(),manager.getPlayer().getProjectiles().get(a).getY(),5,15);
			}
		}

	}
	
	public mainFrame getFrame()
	{
		return f;
	}
}
