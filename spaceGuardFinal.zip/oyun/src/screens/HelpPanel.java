package screens;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import java.awt.Color;

import javax.swing.JLabel;

import oyun.mainFrame;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HelpPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	mainFrame f;
	public HelpPanel(final mainFrame f) {
		setBackground(Color.BLACK);
		
		setSize(800,600);
		this.f=f;
		setLayout(null);
		
		JLabel lblPlayingInstructions = new JLabel("Playing Instructions!");
		lblPlayingInstructions.setFont(new Font("Lucida Grande", Font.BOLD, 60));
		lblPlayingInstructions.setForeground(Color.RED);
		lblPlayingInstructions.setBounds(84, 130, 710, 69);
		add(lblPlayingInstructions);
		
		JLabel lblLeftArrowKey = new JLabel("Left arrow : Moves spaceship left");
		lblLeftArrowKey.setForeground(Color.WHITE);
		lblLeftArrowKey.setBounds(51, 211, 496, 44);
		add(lblLeftArrowKey);
		
		JLabel label = new JLabel("Right arrow : Moves spaceship right");
		label.setForeground(Color.WHITE);
		label.setBounds(51, 247, 496, 44);
		add(label);
		
		JLabel label_1 = new JLabel("Up arrow : Moves spaceship up");
		label_1.setForeground(Color.WHITE);
		label_1.setBounds(51, 281, 496, 44);
		add(label_1);
		
		JLabel label_2 = new JLabel("Down arrow: Moves spaceship down");
		label_2.setForeground(Color.WHITE);
		label_2.setBounds(51, 320, 496, 44);
		add(label_2);
		
		JLabel label_3 = new JLabel("Escape button : Pauses the game!");
		label_3.setForeground(Color.WHITE);
		label_3.setBounds(74, 396, 496, 44);
		add(label_3);
		
		ImageIcon back = new ImageIcon("img/left.png");

		JButton btnBack = new JButton(back);
		btnBack.addActionListener(new ActionListener()  {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				f.showMenu();
			}
		});
		btnBack.setBounds(42, 448, 74, 67);
		add(btnBack);

	}
}
