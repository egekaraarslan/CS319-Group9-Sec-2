package screens;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;

import oyun.mainFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GameOverPanel extends JPanel {

	/**
	 * Create the panel.
	 */
mainFrame f;
public GameOverPanel(final mainFrame f,int score) {
		setBackground(Color.BLACK);
		setSize(800,600);
		setLayout(null);
		this.f=f;
		JLabel lblGameOver = new JLabel("GAME OVER!");
		lblGameOver.setForeground(Color.WHITE);
		lblGameOver.setFont(new Font("Lucida Grande", Font.BOLD, 44));
		lblGameOver.setBounds(224, 69, 511, 86);
		add(lblGameOver);
		
	
	
		JLabel lblYourScore = new JLabel("Your Score: ");
		lblYourScore.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblYourScore.setForeground(Color.GREEN);
		lblYourScore.setBounds(42, 230, 152, 62);
		add(lblYourScore);
		
		JLabel label = new JLabel(""+score);
		label.setForeground(Color.GREEN);
		label.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		label.setBounds(246, 230, 152, 62);
		add(label);
		
		ImageIcon back = new ImageIcon("img/left.png");

		JButton btnBack = new JButton(back);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				f.setVisible(true);
			}
		});
		btnBack.setBounds(42, 448, 74, 67);
		add(btnBack);
		
		ImageIcon repeat = new ImageIcon("img/replay.png");

		JButton btnNewButton = new JButton(repeat);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
				f.showGame();
			}
		});
		btnNewButton.setBounds(571, 456, 95, 74);
		add(btnNewButton);
		

	}
}
