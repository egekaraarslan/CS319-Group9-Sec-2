package screens;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;

import oyun.SettingInfo;
import oyun.mainFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import listeners.MenuActionListener;

public class MainMenu extends Menu{

	/**
	 * Create the panel.
	 */
	
	
	
	SettingInfo info;
	JButton btnNewGame,btnSettings,btnHelp,btnCredits,btnNewButton;
	Image img=new ImageIcon("img/menubg.jpg").getImage();
	ArrayList<Integer> highScores;
	
	
	public MainMenu(mainFrame f) {
		super(f);
		setSize(800,600);
		setLayout(null);
		highScores=new ArrayList<Integer>();
		
		
		Scanner fileScan;
		try {
			fileScan = new Scanner(new File("scores.txt"));
			while(fileScan.hasNext())
			{
				String line=fileScan.nextLine();
				int score=Integer.parseInt(line)/123-2;
				highScores.add(score);
				
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		this.info=new SettingInfo("easy", new ImageIcon("img/bg1.jpg").getImage());
		 btnNewGame = new JButton("NEW GAME!");
		btnNewGame.setBounds(165, 106, 159, 52);
		add(btnNewGame);
		
		 btnSettings = new JButton("SETTINGS");
		btnSettings.setBounds(165, 215, 159, 52);
		add(btnSettings);
		
		JButton btnHelp = new JButton("HELP");
		btnHelp.setBounds(165, 342, 159, 52);
		add(btnHelp);
		
		btnCredits = new JButton("CREDITS");
		btnCredits.setBounds(165, 447, 159, 52);
		add(btnCredits);
		
		JButton btnNewButton = new JButton("EXIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setBounds(165, 525, 159, 52);
		add(btnNewButton);
		
		MenuActionListener actionListener=new MenuActionListener(this,btnNewGame,btnSettings,btnHelp,btnCredits,btnNewButton);
		
		btnNewGame.addActionListener(actionListener);
		btnCredits.addActionListener(actionListener);
		btnHelp.addActionListener(actionListener);
		btnNewButton.addActionListener(actionListener);
		btnSettings.addActionListener(actionListener);
		
		JLabel lblCredits = new JLabel("High Scores!");
		lblCredits.setBackground(Color.BLACK);
		lblCredits.setForeground(Color.RED);
		lblCredits.setFont(new Font("Lucida Grande", Font.BOLD, 36));
		lblCredits.setBounds(556, 46, 430, 84);
		add(lblCredits);


	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage(img, 0, 0, null);
		//DRAWING High scores
		
		g.setFont(new Font("Lucida Grande", Font.BOLD, 50));
		g.setColor(Color.yellow);
		int y=180;
		int a=(highScores.size()<=5)?0:highScores.size()-5;
		for(;a<highScores.size();a++)
		{
			
			g.drawString(""+highScores.get(a), 630, y);
			y=y+80;

		}
	}

	public void startGame()
	{
		frame.getContentPane().add(new mainGamePanel(frame, info));
		setVisible(false);
	}
	public void displaySettings()
	{
		frame.getContentPane().add(new SettingsPanel(this));
		setVisible(false);
	}
	public void displayCredits()
	{
		frame.getContentPane().add(new CreditsPanel(frame));
		setVisible(false);
	}
	public void displayHelp()
	{
		frame.getContentPane().add(new HelpPanel(frame));
		setVisible(false);
	}
	public void exitGame()
	{
		System.exit(0);
	}
	public void setInfo(SettingInfo info)
	{
		this.info=info;
	}
	public void applySettings(SettingInfo s)
	{
		setInfo(s);
	}
}
