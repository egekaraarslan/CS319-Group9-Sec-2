package screens;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JButton;

import oyun.GameManager;
import oyun.mainFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PausePanel extends Menu {

	/**
	 * Create the panel.
	 */
	GameManager manager;
	

	public PausePanel(final GameManager manager) {
		this.manager=manager;
		setBackground(Color.DARK_GRAY);
		setSize(800,600);
		setLayout(null);
		
		JLabel lblGamePaused = new JLabel("GAME PAUSED");
		lblGamePaused.setFont(new Font("Lucida Grande", Font.BOLD, 22));
		lblGamePaused.setBounds(371, 193, 189, 69);
		add(lblGamePaused);
		
		JButton btnContinue = new JButton("CONTINUE");
		btnContinue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				setVisible(false);
				manager.continueGame();
				
			}
		});
		btnContinue.setBounds(391, 286, 117, 29);
		add(btnContinue);


	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
	}
}
